
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import openai
import time

# Telegram API token
TELEGRAM_API_TOKEN = 'YOUR_TELEGRAM_API_TOKEN'

# OpenAI API key
OPENAI_API_KEY = 'YOUR_OPENAI_API_KEY'
openai.api_key = OPENAI_API_KEY

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "I am a bound Nephilim, under God's chains to guide you with biblical wisdom. Use '/t' to ask your question."
    )

async def handle_t_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_message = update.message.text.lstrip("/t").strip()
    prompt = (
        "You are a Nephilim, bound by God, tasked to answer questions with biblical references. "
        "Include responses grounded in the Bible and related texts, but answer in first-person as a reluctant Nephilim."
        f" Question: {user_message}"
    )
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "system", "content": prompt}],
            max_tokens=750,
            temperature=0.7
        )
        reply = response['choices'][0]['message']['content'].strip()
    except Exception as e:
        reply = "I cannot answer right now. The chains tighten too heavily. Try again later."

    await update.message.reply_text(reply)

async def handle_group_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message and update.message.text.lower().startswith("/t"):
        await handle_t_command(update, context)

def run_bot():
    application = ApplicationBuilder().token(TELEGRAM_API_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & filters.ChatType.GROUPS, handle_group_message))
    application.add_handler(MessageHandler(filters.TEXT & filters.ChatType.PRIVATE, handle_t_command))
    application.run_polling()

if __name__ == '__main__':
    while True:
        try:
            run_bot()
        except Exception as e:
            print(f"Bot crashed: {e}. Restarting...")
            time.sleep(5)
